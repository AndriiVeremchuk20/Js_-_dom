//scroll bar 
const pageProgress = document.querySelector('.my-progress-bar');
window.addEventListener('scroll', () => {
    pageProgress.style.width = (document.body.scrollTop || document.documentElement.scrollTop /
        (document.documentElement.scrollHeight - document.documentElement.clientHeight) * 100) + '%';
})

//info about browser
const getBrowserNameVersion = () => {
    let usAg = navigator.userAgent.toLowerCase();
    switch (true) {
        case usAg.indexOf("edge") > -1:
            return `MS Edge ${usAg.split('edge/')[1]}`;
        case usAg.indexOf("edg/") > -1:
            return `Edge ( chromium based) ${usAg.split('adg/')[1]}`;
        case usAg.indexOf("opr") > -1 && !!window.opr:
            return `Opera ${usAg.split('opr/')[1]}`;
        case usAg.indexOf("chrome") > -1 && !!window.chrome:
            return `Chrome ${usAg.split('chrome/')[1]}`;
        case usAg.indexOf("trident") > -1:
            return `MS IE ${usAg.split('trident/')[1]}`;
        case usAg.indexOf("firefox") > -1:
            return `Mozilla Firefox ${usAg.split('firefox/')[1]}`;
        case usAg.indexOf("safari") > -1:
            return `Safari ${usAg.split('safari/')[1]}`;
        default:
            return "other";
    }
}

document.querySelector('#browser-info').innerText = getBrowserNameVersion();

// ban on viewing src or copying text
window.onload = () => {
    document.onkeydown = () => {
        const e = window.event;
        if (e.key == 'F12')
            return false;
        else if (e.ctrlKey & e.shiftKey & e.key == 'i')
            return false;
        else if (e.shiftKey & e.key == 'F10')
            return false;
        else if (e.ctrlKey & e.key == 'u')
            return false;
        else if (e.ctrlKey & e.key == 'a')
            return false;
        else if (e.ctrlKey & e.key == 's')
            return false;
        else if (e.ctrlKey & e.key == 'p')
            return false;
        else if (e.ctrlKey & e.key == 'c')
            return false;
        else if (e.ctrlKey & e.key == 'x')
            return false;
            
    }
    document.oncopy = () => false;

    //document.oncontextmenu = () => false;
}

//Are you here now?
const inactivityTimer = () =>{
    let time, loader = document.querySelector('.you-here');

    const resetTimer = ()=>{
        loader.style.display='none';
        clearTimeout(time);
        time = setTimeout(showModal, 1000*60*5);
    }

    const showModal = ()=>{
        loader.style.display = 'block';
        setTimeout(()=>window.close(),1000*20)
    }

    document.addEventListener('mouseover', resetTimer);
    document.addEventListener('keypress', resetTimer);
    document.addEventListener('scroll', resetTimer);
    document.addEventListener('click', resetTimer);
    document.addEventListener('contextmenu', resetTimer);
}

document.addEventListener('DOMContentLoaded', ()=>{
    inactivityTimer();
})



//smooth scrolling
document.getElementById('point')
 .addEventListener('click', (e)=>{
     document.getElementById('ancor')
     .scrollIntoView(
        {
            block: 'start', 
            behavior: 'smooth',
            inline: 'center'
        }
    );
 })

//change theme
const buttons = [...document.querySelectorAll('.change-theme')];
let changeTheme = false;
buttons.forEach((item)=>{
    item.addEventListener('click', ()=>{
        if(!changeTheme){
            let elemToChange = document.querySelectorAll('.bg-light');
            elemToChange.forEach(item=>{
                item.className = item.className.replace('bg-light', ' bg-dark')
            });
            
            elemToChange = document.querySelectorAll('.bg-white');
            elemToChange.forEach(item=>{
               item.className = item.className.replace('bg-white', ' bg-secondary');     
            })
            changeTheme = true;     
        }
        else{
            let elemToChange = document.querySelectorAll('.bg-dark');
            elemToChange.forEach(item=>{
                item.className = item.className.replace('bg-dark', ' bg-light')
            })
            
            elemToChange = document.querySelectorAll('.bg-secondary');
            elemToChange.forEach(item=>{
               item.className = item.className.replace('bg-secondary', ' bg-white');     
            })
            changeTheme = false;
        }
        
             
    })
})

//https://ru.stackoverflow.com/questions/1004428/%D0%9A%D0%B0%D0%BA-%D1%81%D0%BE%D1%85%D1%80%D0%B0%D0%BD%D0%B8%D1%82%D1%8C-%D0%B8-%D0%BF%D0%B5%D1%80%D0%B5%D0%B4%D0%B0%D1%82%D1%8C-%D0%BF%D0%B0%D1%80%D0%B0%D0%BC%D0%B5%D1%82%D1%80%D1%8B-%D0%BD%D0%B0-%D0%B4%D1%80%D1%83%D0%B3%D1%83%D1%8E-%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D1%83-%D1%87%D0%B5%D1%80%D0%B5%D0%B7-javascript
//show acc data
window.onload = ()=>{
    if(Object.keys(localStorage).length <= 0)
         alert('User is not authorized')    
    else{
        alert(`Name: ${localStorage.getItem('fname')}\n
            Last name: ${localStorage.getItem('lname')}\n
            Email: ${localStorage.getItem('email')}\n
            Password: ${localStorage.getItem('password')}`)
    }
    localStorage.clear();
}