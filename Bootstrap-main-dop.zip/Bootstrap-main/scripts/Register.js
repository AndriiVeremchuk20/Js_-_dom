const fName = document.querySelector('[name="firstName"]');
const lName = document.querySelector('[name="lastName"]')
const email = document.querySelector('[name="email"]');
const password = document.querySelector('[name="password"]')
const repPassword = document.querySelector('[name="repeatPassword"]')


const handleSubmit = (e) => {
    e.preventDefault();

    if(!checkName(fName.value)){
        alert('Invalid name');
        fName.focus();
        return;
    }else if(!checkName(lName.value)){
        alert('Invalid last name');
        lName.focus();
        return;
    }else if(!checkEmail(email.value)){
        alert('Invalid email');
        email.focus();
        return;
    }else if(!checkPasswords(password.value, repPassword.value)){
        alert('Invalid passwords');
        password.focus();
        return;
    }

    localStorage.setItem('fname', fName.value);
    localStorage.setItem('lname', lName.value); 
    localStorage.setItem('email', email.value); 
    localStorage.setItem('password', password.value); 

    fName.value = lName.value = email.value = password.value = repPassword.value = '';

    window.location = './pages/Profile.html'
}

const checkName = name =>
    name?name.search(/\d/)==-1:false;

//https://www.w3resource.com/javascript/form/email-validation.php
const checkEmail = email =>
   email?email.match( /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/):false;

const checkPasswords = (ps1, ps2)=>
    ps1&&ps2?ps1===ps2&&ps1.length>6&&ps2.length:false;

